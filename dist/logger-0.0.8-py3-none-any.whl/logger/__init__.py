from .logger import Logger
import colorama
colorama.init()

__all__ = ['Logger']
